def search4vowels(phrase:str) -> set:
    """ Zwraca samogłoski znalezione w podanym słowie """
    vowels = set('aeiou')
    return vowels.intersection(set(phrase))

def search4letters(phrase:str, letters:str = 'aeiou') -> set:
    """ Funkcja zwraca zbiór liter ze zmiennej letters
     znalezionych w zmiennej phrase"""
    return set(letters).intersection(set(phrase))
